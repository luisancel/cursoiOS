//
//  NumbersViewController.swift
//  tarea02
//
//  Created by Luis Sanchez Celedon on 2/11/19.
//  Copyright © 2019 Luis Sanchez Celedon. All rights reserved.
//

import UIKit

class NumbersViewController: UIViewController {
    // Punto 2 - Arreglo de enteros 
    var arrayInt = [Int]()
    
    @IBOutlet weak var tabla: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        registerCustomTableView()

    }
    
    func registerCustomTableView(){
        let nib = UINib(nibName: "CustomTableViewCell", bundle: nil)
        
        for i in 1000...1999 {
            arrayInt.append(i)
        }
        
        tabla.register(nib, forCellReuseIdentifier: "CustomTableViewCell")
    }

}

// Extension de la clase del NumbersViewController
extension NumbersViewController: UITableViewDelegate, UITableViewDataSource {
    // esto define la altura de la celda
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0
    }
    // cantidad de elementos a imprimir
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1000
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "CustomTableViewCell") as?
            CustomTableViewCell
        else {
            return UITableViewCell()
        }
        
        cell.txtNumber.text = String(arrayInt[indexPath.row])
        
        if (arrayInt[indexPath.row] % 2 == 0){
            cell.cellView.layer.backgroundColor = UIColor.blue.cgColor
        }else{
            cell.cellView.layer.backgroundColor = UIColor.red.cgColor
        }
        
        return cell
    }
}
