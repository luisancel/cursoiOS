import UIKit
// Tarea 1: Luis Eduardo Sanchez Celedon

// Parte 1
class Dog{
    var name : String
    var color : String
    var ager : Int
    
    init(name: String, color: String, ager: Int){
        self.name = name
        self.color = color
        self.ager = ager
    }
}

class Person{
    var name: String
    var identifier: String
    var age:  Int
    var dogs: [Dog]
    
    init(name: String, identifier: String, age: Int){
        self.name = name
        self.identifier = identifier
        self.age = age
        dogs = [Dog]()
    }
}

// Parte 2

func newPerson(){
    // Persona 1
    let person1 : Person = Person(name: "Luis", identifier: "112341234", age: 41)
    let dog1P1 : Dog = Dog(name: "Sherlok", color: "blanco", ager: 4)
    let dog2P1 : Dog = Dog(name: "Cabo", color: "negro", ager: 2)
    person1.dogs.append(dog1P1)
    person1.dogs.append(dog2P1)
    // Persona 2
    let person2 : Person = Person(name: "Eduardo", identifier: "112341235", age: 11)
    let dog1P2 : Dog = Dog(name: "Bruno", color: "gris", ager: 5)
    let dog2P2 : Dog = Dog(name: "Flecha",color: "amarillo", ager: 3)
    person2.dogs.append(dog1P2)
    person2.dogs.append(dog2P2)
    //Persona 3
    let person3 : Person = Person(name: "Lucia", identifier: "112341236", age: 7)
    let dog1P3 : Dog = Dog(name: "Max", color: "gris", ager: 2)
    let dog2P3 : Dog = Dog(name: "Bobby",color: "amarillo", ager: 2)
    person3.dogs.append(dog1P3)
    person3.dogs.append(dog2P3)
   
    let persons = [person1, person2, person3]
    var dogs : Int = 1
    
    for indexP in persons {
        dogs = 1
        print("Nombre: \(indexP.name)")
        print("Identificador: \(indexP.identifier)")
        print("Edad: \(indexP.age)")
        print("Cantidad de perros: \(indexP.dogs.count)")
        
        for indexD in indexP.dogs{
            print("\t Perro \(dogs)")
            print("\t\t Nombre: \(indexD.name)")
            print("\t\t Color: \(indexD.color)")
            print("\t\t Edad: \(indexD.ager)")
            dogs += 1
        }
        print("\n")
    }
}
// Se llama al metodo para imprimir las personas
newPerson()

// Parte 3

func calcularPrimos(num: Int) -> [Int]{
    print("El numero es: \(num)")
    var result = [Int]()
    for x in 1...num{
        var nPrimo =  true
        if (x > 1){
            for y in 2..<x{
                if (x % y == 0){
                    nPrimo =  false
                    break
                }
            }
            if nPrimo{
                result.append(x)
            }
        }
    }
    print("El array resultado sera: \(result)")
    return result
}

let numeroPrimo = calcularPrimos(num: 20)

// Parte 4

func mergeArray(array1: [Int], array2: [Int]){
    var merge = array1 + array2
    merge.sort(by: {$0 < $1})
    print("Array 1: \(array1)")
    print("Array 2: \(array2)")
    print("Resultado = \(merge)")
}

var array1 = [4,2,5]
var array2 = [20, 12, 1]

mergeArray(array1: array1, array2: array2)

