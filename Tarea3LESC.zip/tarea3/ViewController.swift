//
//  ViewController.swift
//  tarea3
//
//  Created by Luis Eduardo Sanchez Celedon on 2/19/19.
//  Copyright © 2019 LESC. All rights reserved.
//

import UIKit
import RealmSwift

class ViewController: UIViewController {
    
    @IBOutlet weak var tabla: UITableView!
    
    @IBOutlet weak var textField : UITextField!
    
    var articulos : Results<Item>? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        actualizarListaArticulos()
        registerCustomCell()
        
    }
    
    @IBAction func agregar(_ sender: Any) {
        addItem()
        actualizarListaArticulos()
    }
    
    func addItem(){
        let alert = UIAlertController(title: "Agregar Articulo", message: "Nombre del Articulo", preferredStyle: UIAlertController.Style.alert)
        let action = UIAlertAction(title: "Name Input", style: .default) { (alertAction) in
            let textField = alert.textFields![0] as UITextField
        }
        alert.addTextField { (textField) in
            textField.placeholder = "Articulo"
        }
        
        alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler:{ (UIAlertAction)in
            
            let item = Item()
            item.date = Date()
            item.title = alert.textFields?[0].text ?? "Sin datos"
            
            self.guardarArticulos(articulo: item)
        }))
        
        alert.addAction(UIAlertAction(title: "Cancelar", style: UIAlertAction.Style.cancel,handler:{(UIAlertAction) in }))
        
        self.present(alert, animated: true, completion: nil)
        
        // No Funciono lo del Ejemplo ....
        //alert.addAction(action)
        //self.view.present(ViewController, animated:true, completion: nil)
        
    }
    
    private func actualizarListaArticulos(){
        do{
            let realm = try Realm()
            
            self.articulos = realm.objects(Item.self)
            if self.articulos != nil {
               tabla.reloadData()
            }
            
        }catch{
            print("ERROR ACTUALIZANDO: \(error)")
        }
    }
    
    private func guardarArticulos(articulo: Object){
        do{
            let realm = try Realm()
            try realm.write {
                realm.add(articulo, update: true)
                
                self.actualizarListaArticulos()
            }
        }catch let error as NSError {
            print("ERRROR GUARDANDO: \(error)")
        }
    }
    
    private func eliminarArticulos(articulo: Object){
        do{
            let realm = try Realm()
            try realm.write {
                realm.delete(articulo)
            }
        }catch let error as NSError {
            print("ERROR BORRANDO: \(error)")
        }
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.articulos == nil{
            return 0
        }else{
            return self.articulos?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ItemTableViewCell") as? ItemTableViewCell else {
            return UITableViewCell()
        }
        
        if let articulos = articulos {
            let articulo = articulos[indexPath.row]
            cell.setupCell(item: articulo)
        }
        
        return cell
    }
    
    // Registra la celda custom
    private func registerCustomCell() {
        let nib = UINib(nibName: "ItemTableViewCell", bundle: nil)
        tabla.register(nib, forCellReuseIdentifier: "ItemTableViewCell")
    }
    
    // Aqui borra la celda
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            self.eliminarArticulos(articulo: (self.articulos?[indexPath.row])!)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            //No se hace nada
        }
    }


}

