//
//  Item.swift
//  tarea3
//
//  Created by Luis Eduardo Sanchez Celedon on 2/20/19.
//  Copyright © 2019 LESC. All rights reserved.
//

import Foundation
import RealmSwift

class Item:Object {
    @objc dynamic var date = Date()
    @objc dynamic var title = ""
    @objc dynamic var id = UUID().uuidString
    
    override static func primaryKey() -> String?{
        return "id"
    }
    
    override static func indexedProperties() -> [String]{
        return ["titulo"]
    }
}




