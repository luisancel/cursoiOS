//
//  ItemTableViewCell.swift
//  tarea3
//
//  Created by Luis Eduardo Sanchez Celedon on 2/22/19.
//  Copyright © 2019 LESC. All rights reserved.
//

import UIKit

class ItemTableViewCell: UITableViewCell {

    @IBOutlet weak var txtItem: UILabel!
    @IBOutlet weak var txtDate: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setupCell(item: Item) {
        txtItem.text = item.title
        txtDate.text = item.date.getFormatted(dateStyle: .medium, timeStyle: .short)
    }
    
}

extension Date {
    func getFormatted(dateStyle: DateFormatter.Style, timeStyle: DateFormatter.Style) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale.current
        formatter.dateStyle = dateStyle
        formatter.timeStyle = timeStyle
        let localizedDate = formatter.string(from: self as Date)
        return localizedDate
    }
}
