import UIKit

//cesarbreso@hotmail.com

/// 1

func esSumaImpares(arrayNum : [Int]) -> Bool{
    var sumaPar : Int = 0
    var sumaImpar : Int = 0
    var esImpar : Bool = false
    for index in 1..arrayNum.coun{
        if (arrayNum[index] % 2 == 0) {
            sumaPar = sumaPar + arrayNum[index]
        }else{
            sumaImpar = sumaImpar + arrayNum[index]
        }
    }
    if sumaPar > sumaImpar{
        esImpar = true
    }
    return esImpar
}

// 2

func arregloDivisores(numero : Int) -> [Int]{
    var arreglo = [Int]()
    if (numero > 1){
        for index in 1..numero{
            if (cont % 2 == 0){
                arreglo.append(index)
            }
        }
    }
    
    return arreglo
}

// 3
func sumaArreglo(arrayFloat : [Float]) -> Float{
    var promedio : Float = 0,0
    for index in 1..arrayFloat.count{
        
    }
    
}
