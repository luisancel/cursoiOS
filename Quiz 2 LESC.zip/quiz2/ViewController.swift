//
//  ViewController.swift
//  quiz2
//
//  Created by Luis Eduardo Sanchez Celedon on 2/23/19.
//  Copyright © 2019 LESC. All rights reserved.
//

import UIKit
import RealmSwift

class ViewController: UIViewController {
    
    @IBOutlet weak var tabla: UITableView!
    
    var cat : Results<Cat>? = nil


    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        add(name: "1", order: 0 , color: "Rojo")
        add(name: "2", order: 1 , color: "Amarillo")
        add(name: "3", order: 2 , color: "Verde")
        add(name: "4", order: 3 , color: "Morado")
        add(name: "5", order: 4 , color: "Rosado")
        add(name: "6", order: 5 , color: "Gris")
        add(name: "7", order: 6 , color: "Negro")
        add(name: "8", order: 7 , color: "Azul")
        add(name: "9", order: 8 , color: "Celeste")
        add(name: "10", order: 9 , color: "Naranja")

    }

    
    func add(name: String, order: Int, color: String){
        let cat = Cat()
        cat.name = name
        cat.order = order
        cat.color = color
        self.guardar(cat: cat)
    }
    
    func guardar(cat: Cat){
        do{
            let realm = try Realm()
            try realm.write {
                
                realm.add(cat, update: true)
                
                self.actualizar()
            }
        }catch let error as NSError {
            print("ERRROR GUARDANDO: \(error)")
        }
    }
    
    func actualizar(){
        do{
            let realm = try Realm()
            
            self.cat = realm.objects(Cat.self)
            if self.cat != nil {
                cat?.sorted(byKeyPath: "order", ascending: false)
                tabla.reloadData()
            }
            
        }catch{
            print("ERROR ACTUALIZANDO: \(error)")
        }
    }
    
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.cat == nil{
            return 0
        }else{
            return self.cat?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "CustomTableViewCell") as? CustomTableViewCell else {
            return UITableViewCell()
        }
        
        if let cat = cat {
            let cat = cat[indexPath.row]
            cell.setupCell(cat: cat)
        }
        
        return cell
    }
    
    // Registra la celda custom
    private func registerCustomCell() {
        let nib = UINib(nibName: "CustomTableViewCell", bundle: nil)
        tabla.register(nib, forCellReuseIdentifier: "CustomTableViewCell")
    }
    
    
}

