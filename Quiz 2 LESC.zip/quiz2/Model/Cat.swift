//
//  Cat.swift
//  quiz2
//
//  Created by Luis Eduardo Sanchez Celedon on 2/23/19.
//  Copyright © 2019 LESC. All rights reserved.
//

import Foundation
import RealmSwift

class Cat:Object {
    @objc dynamic var name = ""
    @objc dynamic var order = 0
    @objc dynamic var color = ""
    @objc dynamic var id = UUID().uuidString
    
    override static func primaryKey() -> String?{
        return "id"
    }
    
    override static func indexedProperties() -> [String]{
        return ["name"]
    }
}






