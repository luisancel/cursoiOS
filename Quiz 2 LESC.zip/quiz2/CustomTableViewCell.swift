//
//  CustomTableViewCell.swift
//  quiz2
//
//  Created by Luis Eduardo Sanchez Celedon on 2/23/19.
//  Copyright © 2019 LESC. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    @IBOutlet weak var nombre: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setupCell(cat: Cat){
        nombre.text = cat.name
    }
    
}
