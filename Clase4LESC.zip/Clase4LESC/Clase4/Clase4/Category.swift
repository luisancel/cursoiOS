//
//  Category.swift
//  Clase4
//
//  Created by Luis Eduardo Sanchez Celedon on 2/15/19.
//  Copyright © 2019 LESC. All rights reserved.
//

import Foundation

class Category{
    var name : String
    var image : String
    var news = [News]()
    
    init(name: String, image: String){
        self.name = name
        self.image = image
    }
}
