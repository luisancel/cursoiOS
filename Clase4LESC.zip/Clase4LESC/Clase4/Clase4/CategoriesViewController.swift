//
//  CategoriesViewController.swift
//  Clase4
//
//  Created by Luis Eduardo Sanchez Celedon on 2/15/19.
//  Copyright © 2019 LESC. All rights reserved.
//

import UIKit

class CategoriesViewController: UIViewController {

    
    @IBOutlet weak var tableCat: UITableView!
    
    var categories = [Category]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let catDeportes = Category(name: "Deportes", image: "sports")
        let catSucesos = Category(name: "Sucesos", image: "incident")
        let catEconomia = Category(name: "Economía", image: "economy")
        let catTecnologia = Category(name: "Tecnología", image: "technology")
        
        categories.append(catSucesos)
        categories.append(catEconomia)
        categories.append(catDeportes)
        categories.append(catTecnologia)
        
        registerCustomTableView()
    }
    
    func registerCustomTableView(){
        let nib = UINib(nibName: "CategoryTableViewCell", bundle: nil)
        tableCat.register(nib, forCellReuseIdentifier: "CategoryTableViewCell")
        
        // Do any additional setup after loading the view.
    }
}

extension CategoriesViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        guard let celda = tableView.dequeueReusableCell(withIdentifier: "CategoryTableViewCell") as? CategoryTableViewCell else {
            return UITableViewCell()
        }
        
        let img: UIImage = UIImage(named: categories[indexPath.row].image)!
        celda.ImageCategoria.image = img
                
        celda.nameCategoria.text = categories[indexPath.row].name
        
        return celda
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80.0 //Altura de la celda
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc : NewsViewController = storyboard.instantiateViewController(withIdentifier: "NewsViewController") as! NewsViewController

        let navController = UINavigationController(rootViewController: vc)
        
        vc.category = categories[indexPath.row]
        self.present(navController, animated: true, completion: nil)
    }
}
