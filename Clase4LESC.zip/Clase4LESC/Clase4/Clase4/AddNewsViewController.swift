//
//  AddNewsViewController.swift
//  Clase4
//
//  Created by Luis Eduardo Sanchez Celedon on 2/15/19.
//  Copyright © 2019 LESC. All rights reserved.
//

import UIKit

protocol AddNewsViewControllerDelegate: class{
    func publicarNoticia(news: News)
}

class AddNewsViewController: UIViewController {

    weak var delegate: AddNewsViewControllerDelegate?
    
    @IBOutlet weak var txtTitulo: UITextField!
    @IBOutlet weak var txtCuerpo: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtCuerpo.layer.borderWidth = 1
        txtCuerpo.layer.borderColor = UIColor.gray.cgColor
    }
    
    @IBAction func crearNoticia(_ sender: Any) {
        if let titulo = txtTitulo.text, let cuerpo = txtCuerpo.text {
            var news : News = News(createdAt: Date(), title: titulo ?? "", body: cuerpo)
            
            publicarNoticia(news: news)
        }else{
            showAlertController()
        }
    }
    
    func publicarNoticia(news: News){
        delegate?.publicarNoticia(news: news)
    }
    
    func showAlertController(){
        let alertController = UIAlertController(title: "Error", message: "Debe llenar todos los campos", preferredStyle: .alert)
        let action  = UIAlertAction(title: "OK", style: .default) { (_) in
            self.txtTitulo.becomeFirstResponder()
        }
        alertController.addAction(action)
        present(alertController, animated: true, completion: nil)
    }
}
