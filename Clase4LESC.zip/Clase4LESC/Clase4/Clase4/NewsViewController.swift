//
//  NewsViewController.swift
//  Clase4
//
//  Created by Luis Eduardo Sanchez Celedon on 2/15/19.
//  Copyright © 2019 LESC. All rights reserved.
//

import UIKit

class NewsViewController: UIViewController {

    var category : Category = Category(name: "", image: "")
    let df = DateFormatter()
    
    @IBOutlet weak var lblTitulo: UILabel!
    
    @IBOutlet weak var tabla: UITableView!
    
    @IBOutlet weak var imgCategoria: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblTitulo.text = category.name
        
        let img: UIImage = UIImage(named: category.image)!
        
        imgCategoria.image = img
        
        df.dateFormat = "dd/MM/yyyy hh:mm:ss"
        
        registerCustomTableView()
        // Do any additional setup after loading the view.
        
    }
        
        @IBAction func addNewsAction(_ sender: Any) {
            let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc : AddNewsViewController = storyboard.instantiateViewController(withIdentifier: "AddNewsViewController") as! AddNewsViewController
            
            vc.delegate = self
        
            self.present(vc, animated: true, completion: nil)
        }
        
        func registerCustomTableView(){
            let nib = UINib(nibName: "NewsTableViewCell", bundle: nil)
            tabla.register(nib, forCellReuseIdentifier: "NewsTableViewCell")
        }
    }
    
    extension NewsViewController: AddNewsViewControllerDelegate {
        func publicarNoticia(news: News) {
            dismiss(animated: true, completion: nil)
            category.news.append(news)
            tabla.reloadData()
        }
    }
    
    extension NewsViewController: UITableViewDelegate, UITableViewDataSource{
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return category.news.count;
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

            guard let celda = tableView.dequeueReusableCell(withIdentifier: "NewsTableViewCell") as? NewsTableViewCell else {
                return UITableViewCell()
            }
                        
            celda.title.text = category.news[indexPath.row].title
            celda.date.text = self.df.string(from: category.news[indexPath.row].createdAt)
            celda.body.text = category.news[indexPath.row].body
            
            return celda
        }
        
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 80.0
        }
        
        func numberOfSections(in tableView: UITableView) -> Int {
            return 1
        }
        
        func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
            
            if editingStyle == .delete {

                category.news.remove(at: indexPath.row)
                
                tableView.deleteRows(at: [indexPath], with: .fade)
                
            } else if editingStyle == .insert {
                //No se hace nada si falla
            }
        }
}
