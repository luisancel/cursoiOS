//
//  CategoryTableViewCell.swift
//  Clase4
//
//  Created by Luis Eduardo Sanchez Celedon on 2/15/19.
//  Copyright © 2019 LESC. All rights reserved.
//

import UIKit

class CategoryTableViewCell: UITableViewCell {

    @IBOutlet weak var nameCategoria: UILabel!
    @IBOutlet weak var ImageCategoria: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}


