//
//  News.swift
//  Clase4
//
//  Created by Luis Eduardo Sanchez Celedon on 2/15/19.
//  Copyright © 2019 LESC. All rights reserved.
//

import Foundation


struct News {
    var createdAt : Date
    var title : String
    var body : String
}
